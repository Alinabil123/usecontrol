﻿
namespace Demo_User_control
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cu_state1 = new Demo_User_control.cu_state();
            this.btn1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cu_state1
            // 
            this.cu_state1.Location = new System.Drawing.Point(12, 12);
            this.cu_state1.Name = "cu_state1";
            this.cu_state1.Size = new System.Drawing.Size(644, 176);
            this.cu_state1.TabIndex = 0;
            // 
            // btn1
            // 
            this.btn1.Location = new System.Drawing.Point(232, 258);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(112, 51);
            this.btn1.TabIndex = 1;
            this.btn1.Text = "state";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(710, 444);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.cu_state1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private cu_state cu_state1;
        private System.Windows.Forms.Button btn1;
    }
}

