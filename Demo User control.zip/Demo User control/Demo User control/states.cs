﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Demo_User_control
{
    public class states
    {
        public int ID { get; set; }
        public string name { get; set; }
    }
}
