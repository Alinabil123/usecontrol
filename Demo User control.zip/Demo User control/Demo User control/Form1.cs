﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Demo_User_control
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(string.Format("state id={0},name={1}", cu_state1.selectedState.ID, cu_state1.selectedState.name), "message", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
