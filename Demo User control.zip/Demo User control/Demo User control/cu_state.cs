﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Demo_User_control
{
    public partial class cu_state : UserControl
    {
        public cu_state()
        {
            InitializeComponent();
        }
        public states selectedState
        {
            get
            {
                return (states)cboState.SelectedItem;
            }
        }

        private void cu_state_Load(object sender, EventArgs e)
        {
            List<states> list = new List<states>();
            list.Add(new states() { ID = 1, name = "ali" });
            list.Add(new states() { ID = 2, name = "hamza" });
            list.Add(new states() { ID = 3, name = "abrahem" });
            list.Add(new states() { ID = 4, name = "omer" });
            cboState.DataSource = list;
            cboState.ValueMember = "ID";
            cboState.DisplayMember = "Name";
        }
    }
}
